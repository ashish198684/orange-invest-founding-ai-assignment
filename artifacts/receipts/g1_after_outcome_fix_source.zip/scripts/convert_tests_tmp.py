﻿import ast
from pathlib import Path
from textwrap import indent

path = Path('tests/test_provider_contract.py')
tree = ast.parse(path.read_text(encoding='utf-8-sig'))

class Convert(ast.NodeTransformer):
    def visit_Call(self, node):
        self.generic_visit(node)
        if isinstance(node.func, ast.Attribute) and isinstance(node.func.value, ast.Name) and node.func.value.id == 'pytest' and node.func.attr == 'raises':
            match = next((v.value for v in node.keywords if v.arg == 'match'), None)
            node.func = ast.Attribute(value=ast.Name(id='self', ctx=ast.Load()), attr='assertRaisesRegex' if match else 'assertRaises', ctx=ast.Load())
            if match:
                node.args.insert(1, match)
            node.keywords = []
        return node
    def visit_Attribute(self, node):
        self.generic_visit(node)
        if node.attr == 'value' and isinstance(node.value, ast.Name) and node.value.id == 'exc':
            node.attr = 'exception'
        return node

imports = []
functions = []
for node in tree.body:
    if isinstance(node, ast.Import) and any(a.name == 'pytest' for a in node.names):
        imports.extend(ast.parse('import unittest\nimport tempfile').body)
    elif isinstance(node, ast.FunctionDef) and node.name == 'setup':
        continue
    elif isinstance(node, ast.FunctionDef) and node.name.startswith('test_'):
        params = [(d.args[0].value, d.args[1]) for d in node.decorator_list]
        argnames = [a.arg for a in node.args.args]
        node.decorator_list = []
        node.args.args = [ast.arg(arg='self')]
        node = Convert().visit(node)
        initial = []
        if 'setup' in argnames:
            initial.extend(ast.parse('setup = self.new_setup()').body)
        if 'tmp_path' in argnames:
            initial.extend(ast.parse('tmp_path = self.new_dir()').body)
        body = initial + node.body
        if params:
            keywords = [ast.keyword(arg=n.strip(), value=ast.Name(id=n.strip(), ctx=ast.Load())) for names, _ in params for n in names.split(',')]
            body = [ast.With(items=[ast.withitem(context_expr=ast.Call(func=ast.Attribute(value=ast.Name(id='self', ctx=ast.Load()), attr='subTest', ctx=ast.Load()), args=[], keywords=keywords))], body=body)]
            for names, values in reversed(params):
                target = ast.parse(names, mode='eval').body
                if isinstance(target, ast.Tuple):
                    for elt in target.elts:
                        elt.ctx = ast.Store()
                target.ctx = ast.Store()
                body = [ast.For(target=target, iter=values, body=body, orelse=[])]
        node.body = body
        functions.append(node)
    else:
        # The error helper is standalone, and needs unittest's context manager.
        if isinstance(node, ast.FunctionDef) and node.name == 'error':
            node = Convert().visit(node)
            node = ast.fix_missing_locations(node)
            source = ast.unparse(node).replace('self.assertRaises(', 'unittest.TestCase().assertRaises(')
            imports.extend(ast.parse(source).body)
        else:
            imports.append(node)

helpers = ast.parse('''
def new_dir(self):
    directory = tempfile.TemporaryDirectory()
    self.addCleanup(directory.cleanup)
    return Path(directory.name)

def new_setup(self):
    clock = Clock()
    path = self.new_dir() / 'provider.sqlite3'
    def make(branch='book_success', *, config=None, user='alice'):
        return ProviderMock(path, user_id=user, clock=clock,
                            config=config or ScenarioConfig(book_branch=branch))
    return path, clock, make
''').body
suite = ast.ClassDef(name='ProviderContractTests', bases=[ast.Attribute(value=ast.Name(id='unittest', ctx=ast.Load()), attr='TestCase', ctx=ast.Load())], keywords=[], body=helpers + functions, decorator_list=[])
module = ast.Module(body=imports + [suite] + ast.parse("if __name__ == '__main__':\n    unittest.main()\n").body, type_ignores=[])
path.write_text(ast.unparse(ast.fix_missing_locations(module)) + '\n', encoding='utf-8')
