﻿"""Run pinned workspace-local pytest without modifying the system interpreter."""
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT), str(ROOT / '.vendor')]
import pytest

if __name__ == '__main__':
    raise SystemExit(pytest.main(sys.argv[1:] or ['-q']))
